#!/bin/sh
#
rm -rf /u01/app/oracle/admin/london/adump
rm -rf /u01/app/oracle/oradata/LONDON
rm -rf /u01/app/oracle/oradata/LONDON/pdbseed
rm -rf /u01/app/oracle/oradata/LONDON/dev1
rm -rf /u01/app/oracle/fast_recovery_area/LONDON