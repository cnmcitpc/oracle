#!/bin/sh
#
mkdir -p /u01/app/oracle/admin/london/adump
mkdir -p /u01/app/oracle/oradata/LONDON
mkdir -p /u01/app/oracle/oradata/LONDON/pdbseed
mkdir -p /u01/app/oracle/oradata/LONDON/dev1
mkdir -p /u01/app/oracle/fast_recovery_area/LONDON
