#!/bin/sh
#

mkdir -p /u01/app/oracle/admin/londonFS/adump
mkdir -p /u01/app/oracle/oradata/londonFS
mkdir -p /u01/app/oracle/oradata/londonFS/pdbseed
mkdir -p /u01/app/oracle/oradata/londonFS/dev1
mkdir -p /u01/app/oracle/fast_recovery_area/londonFS
