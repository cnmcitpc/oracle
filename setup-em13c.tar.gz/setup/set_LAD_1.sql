set echo on
alter system set log_archive_dest_1='location=USE_DB_RECOVERY_FILE_DEST valid_for=(ALL_LOGFILES,ALL_ROLES) db_unique_name=boston' scope=both;
alter system set log_archive_dest_state_1='enable' scope=both;
