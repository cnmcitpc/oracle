set echo on
alter database add standby logfile ('/u01/app/oracle/oradata/BOSTON/stdbyredo01.log') size 200M;
alter database add standby logfile ('/u01/app/oracle/oradata/BOSTON/stdbyredo02.log') size 200M;
alter database add standby logfile ('/u01/app/oracle/oradata/BOSTON/stdbyredo03.log') size 200M;
alter database add standby logfile ('/u01/app/oracle/oradata/BOSTON/stdbyredo04.log') size 200M;
