#!/bin/sh
#
scp oracle@host01:/u01/app/oracle/product/19.3.0/dbhome_1/dbs/orapwboston /u01/app/oracle/product/19.3.0/dbhome_1/dbs/orapwlondon