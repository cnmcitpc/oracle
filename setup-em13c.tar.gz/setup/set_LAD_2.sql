set echo on
alter system set log_archive_dest_2='SERVICE=london ASYNC REOPEN=15 valid_for=(ONLINE_LOGFILES,PRIMARY_ROLE) db_unique_name=london' scope=both;

