#!/bin/sh
#
scp /tmp/bostonFS.ctl oracle@host04:/tmp
scp /tmp/initbostonFS.ora oracle@host04:/tmp
scp /tmp/orapwboston oracle@host04:/tmp

