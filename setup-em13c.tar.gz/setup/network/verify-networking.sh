scp -p host01-* oracle@host01:/u01/app/oracle/product/19.3.0/dbhome_1/network/admin
scp -p host02-* oracle@host02:/u01/app/oracle/product/19.3.0/dbhome_1/network/admin
scp -p host03-* oracle@host03:/u01/app/oracle/product/19.3.0/dbhome_1/network/admin
scp -p host04-* oracle@host04:/u01/app/oracle/product/19.3.0/dbhome_1/network/admin

echo "**Diff command on host01 tnsnames.ora**"
plink -X -ssh -pw oracle -l oracle host01 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host01-tnsnames.ora

echo "**Diff command on host01 sqlnet.ora**"
plink -X -ssh -pw oracle -l oracle host01 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/sqlnet.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host01-sqlnet.ora

echo "**Diff command on host01 listener.ora**"
plink -X -ssh -pw oracle -l oracle host01 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/listener.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host01-listener.ora

echo "**Diff command on host02 tnsnames.ora**"
plink -X -ssh -pw oracle -l oracle host02 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host02-tnsnames.ora

echo "**Diff command on host02 sqlnet.ora**"
plink -X -ssh -pw oracle -l oracle host02 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/sqlnet.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host02-sqlnet.ora

echo "**Diff command on host02 listener.ora**"
plink -X -ssh -pw oracle -l oracle host02 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/listener.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host02-listener.ora

echo "**Diff command on host03 tnsnames.ora**"
plink -X -ssh -pw oracle -l oracle host03 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host03-tnsnames.ora

echo "**Diff command on host03 sqlnet.ora**"
plink -X -ssh -pw oracle -l oracle host03 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/sqlnet.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host03-sqlnet.ora

echo "**Diff command on host03 listener.ora**"
plink -X -ssh -pw oracle -l oracle host03 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/listener.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host03-listener.ora

echo "**Diff command on host04 tnsnames.ora**"
plink -X -ssh -pw oracle -l oracle host04 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/tnsnames.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host04-tnsnames.ora

echo "**Diff command on host04 sqlnet.ora**"
plink -X -ssh -pw oracle -l oracle host04 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/sqlnet.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host04-sqlnet.ora

echo "**Diff command on host04 listener.ora**"
plink -X -ssh -pw oracle -l oracle host04 diff /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/listener.ora /u01/app/oracle/product/19.3.0/dbhome_1/network/admin/host04-listener.ora
