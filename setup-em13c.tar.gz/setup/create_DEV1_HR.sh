#!/bin/sh
# use bash shell


export ORACLE_SID=boston
export ORACLE_HOME=/u01/app/oracle/product/19.3.0/dbhome_1
PATH=$ORACLE_HOME/bin:$PATH; export PATH

cd $HOME/setup
$ORACLE_HOME/bin/sqlplus "system/oracle_4U@host01:1521/dev1.example.com" @hr_main.sql oracle_4U users temp /tmp
