alter pluggable database DEV2 close;
alter pluggable database DEV3 close;
drop pluggable database DEV2 including datafiles;
drop pluggable database DEV3 including datafiles;
alter system switch logfile;

