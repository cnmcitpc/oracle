export ORACLE_HOME=/u01/app/oracle/product/19.3.0/dbhome_1
$ORACLE_HOME/bin/dbca -silent -createDatabase \
-responseFile /home/oracle/setup/dbca193.rsp \
-gdbname boston.example.com -sid boston \
-sysPassword "oracle_4U" \
-systemPassword "oracle_4U" \
-datafileDestination /u01/app/oracle/oradata \
-recoveryAreaDestination /u01/app/oracle/fast_recovery_area \
-recoveryAreaSize 15000 \
-templateName General_Purpose.dbc \
-totalMemory 800 \
-emConfiguration DBEXPRESS \
-dbsnmpPassword "oracle_4U" \
-emExpressPort 5500 \
-enableArchive true \
-createAsContainerDatabase true \
-numberOfPDBs 1 \
-pdbName dev1 \
-pdbAdminPassword "oracle_4U" \
-useLocalUndoForPDBs true