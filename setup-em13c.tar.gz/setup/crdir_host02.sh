#!/bin/sh
#
mkdir -p /u01/app/oracle/admin/bostonFS/adump
mkdir -p /u01/app/oracle/oradata/bostonFS
mkdir -p /u01/app/oracle/oradata/bostonFS/pdbseed
mkdir -p /u01/app/oracle/oradata/bostonFS/dev1
mkdir -p /u01/app/oracle/fast_recovery_area/bostonFS
