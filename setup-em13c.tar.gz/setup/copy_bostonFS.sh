#!/bin/sh
#

scp /tmp/initbostonFS.ora oracle@host02:/tmp
scp /tmp/bostonFS.ctl oracle@host02:/tmp
scp /tmp/orapwboston oracle@host02:/tmp