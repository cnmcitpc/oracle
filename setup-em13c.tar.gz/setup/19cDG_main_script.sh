#!/bin/bash
#

(1) 
usermod -g oinstall -G dba,oper,backupdba,dgdba,kmdba,racdba oracle

(2) Installed all required packages
https://oracle-base.com/articles/19c/oracle-db-19c-installation-on-oracle-linux-7

(3) Setup directories
mkdir -p /home/oracle/labs
mkdir -p /home/oracle/setup
chown -R oracle:oinstall /home/oracle

(4) Create DB SW Directories
mkdir -p /u01/app/oracle/product/19.3.0/dbhome_1
chown -R oracle:oinstall /u01
chmod -R 775 /u01

(5) Transfer the DB software
scp /stage/LINUX.X64_193000_db_home.zip /home/oracle/setup
unzip -d /u01/app/oracle/product/19.3.0/dbhome_1 /home/oracle/setup/LINUX.X64_193000_db_home.zip
./runInstaller

(6) Install DB SW
cd /u01/app/oracle/product/19.3.0/dbhome_1/


(7) Create OMA directories
/u01/app/oracle/agent

(8) Change sudo Configuration
echo 'oracle     ALL=(ALL)NOPASSWD:ALL' >> /etc/sudoers
sed -i 's/requiretty/!requiretty/g' /etc/sudoers

(9) em13: Modified listener.ora
# from em13 to em13.example.com

(10) Transfer network configuration files
# All files are placed in /home/oracle/setup

(11) Setup for Auto Startup (on host01)
cp /stage/scripts/dbora /etc/init.d/
chmod 750 /etc/init.d/dbora
chkconfig --add dbora
echo "Done."
echo ""

## hr or sh schema??
## extra directories??
## auto startup setup of em13 host01
## auto startup setup: dbora


=====
# (1) Create boston CDB
     # PDV open save state
	 # at the pdb, exec dbms_xdb_config.sethttpsport(5501);
# (2) Create listener.ora files on all 4 hosts
# (3) Start the LISTENER on all 4 hosts
# (4) Update /etc/oratab file in all 4 hosts in advance




echo "##############################################"
echo "Task 9 of 12: Create and Start Default LSNR   "
echo "##############################################"
echo ""
su - oracle -c "/stage/scripts/D105110GC10_19cNF_LSNR_stop.sh"
su - oracle -c "/stage/scripts/D105110GC10_19cNF_LSNR_start.sh"
echo ""
echo "#########################################"
echo "Task 10 of 12: Run DBCA for ORCL (19c)   "
echo "#########################################"
echo ""
su - oracle -c "/stage/scripts/D105110GC10_19cNF_response_files/crDBorcl.sh"
su - oracle -c "/stage/scripts/D105110GC10_19cNF_reset_ORCL.sh"
/stage/scripts/D105110GC10_19cNF_bashrc.sh
echo ""
echo "#########################################"
echo "Task 11 of 12: Update oratab & dbstart   "
echo "#########################################"
echo ""
mv /etc/oratab /etc/oratab.old
cp /stage/scripts/oratab /etc/oratab
chown oracle:oinstall /etc/oratab
chmod 664 /etc/oratab
mv /u01/app/oracle/product/19.3.0/dbhome_1/bin/dbstart /u01/app/oracle/product/19.3.0/dbhome_1/bin/dbstart.old
cp /stage/scripts/dbstart_new /u01/app/oracle/product/19.3.0/dbhome_1/bin/dbstart
chown oracle:oinstall /u01/app/oracle/product/19.3.0/dbhome_1/bin/dbstart
chmod 750 /u01/app/oracle/product/19.3.0/dbhome_1/bin/dbstart
echo "Done."
echo ""
echo "###########################################"
echo "Task 12 of 12: Enable Auto Startup of DB   "
echo "###########################################"
echo ""
cp /stage/scripts/dbora /etc/init.d/
chmod 750 /etc/init.d/dbora
chkconfig --add dbora
echo "Done."
echo ""
echo "##################################################"
echo "Completed All 12 Tasks. Verify Your Environment   "
echo "##################################################"

