#!/bin/sh
#
echo 'DB_NAME=london' > /u01/app/oracle/product/19.3.0/dbhome_1/dbs/initlondon.ora
echo 'DB_DOMAIN=example.com' >> /u01/app/oracle/product/19.3.0/dbhome_1/dbs/initlondon.ora